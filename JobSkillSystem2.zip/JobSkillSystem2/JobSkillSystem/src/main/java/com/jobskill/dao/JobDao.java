/*package com.jobskill.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jobskill.model.Job;

@Repository
public class JobDao {

    @PersistenceContext
    private EntityManager entityManager;

    // Save a job
    @Transactional
    public void saveJob(Job job) {
        entityManager.persist(job);
    }

    // Get all jobs
    public List<Job> getAllJobs() {
        return entityManager
                .createQuery("FROM Job", Job.class)
                .getResultList();
    }

    // Get jobs posted by a specific employer (using contact number)
    public List<Job> getJobsByEmployer(double contact) {
        TypedQuery<Job> query = entityManager.createQuery(
            "FROM Job WHERE postedBy = :contact", Job.class
        );
        query.setParameter("contact", contact);
        return query.getResultList();
    }

    // Get job by ID
    public Job getJobById(int jobId) {
        return entityManager.find(Job.class, jobId);
    }

    // Delete a job (optional, for admin/employer dashboard)
    @Transactional
    public void deleteJob(int jobId) {
        Job job = entityManager.find(Job.class, jobId);
        if (job != null) {
            entityManager.remove(job);
        }
        
        

        
        
        
    }
    
    
    public List<Job> suggestJobsBySkills(String skills) {
        String[] skillList = skills.split(",");
        StringBuilder query = new StringBuilder("FROM Job j WHERE ");
        for (int i = 0; i < skillList.length; i++) {
            query.append("LOWER(j.skillsRequired) LIKE :skill").append(i);
            if (i != skillList.length - 1) query.append(" OR ");
        }

        TypedQuery<Job> q = entityManager.createQuery(query.toString(), Job.class);
        for (int i = 0; i < skillList.length; i++) {
            q.setParameter("skill" + i, "%" + skillList[i].trim().toLowerCase() + "%");
        }

        return q.getResultList();
    }
    
    
   

    
    
}
*/



package com.jobskill.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jobskill.model.Job;

@Repository
public class JobDao {

    @PersistenceContext
    private EntityManager entityManager;

    // Save a job
    @Transactional
    public void saveJob(Job job) {
        entityManager.persist(job);
    }

    // Get all jobs
    public List<Job> getAllJobs() {
        return entityManager.createQuery("FROM Job", Job.class).getResultList();
    }

    // Get jobs posted by a specific employer (using contact number)
    public List<Job> getJobsByEmployer(double contact) {
        TypedQuery<Job> query = entityManager.createQuery(
            "FROM Job WHERE postedBy = :contact", Job.class);
        query.setParameter("contact", contact);
        return query.getResultList();
    }

    // Get job by ID
    public Job getJobById(int jobId) {
        return entityManager.find(Job.class, jobId);
    }

    // Delete a job
    @Transactional
    public void deleteJob(int jobId) {
        Job job = entityManager.find(Job.class, jobId);
        if (job != null) {
            entityManager.remove(job);
        }
    }
    
    public List<Job> searchJobs(String keyword, String type) {
        String jpql = "FROM Job j WHERE (LOWER(j.title) LIKE :kw OR LOWER(j.description) LIKE :kw)";
        if (type != null && !type.isEmpty()) {
            jpql += " AND j.type = :type";
        }

        TypedQuery<Job> query = entityManager.createQuery(jpql, Job.class);
        query.setParameter("kw", "%" + keyword.toLowerCase() + "%");
        if (type != null && !type.isEmpty()) {
            query.setParameter("type", type);
        }

        return query.getResultList();
    }

    
    

    // Suggest jobs by matching skills (used in skill-matching feature)
    public List<Job> getSuggestedJobs(String seekerSkills) {
        List<Job> allJobs = getAllJobs(); // or however you're fetching jobs
        List<Job> suggestedJobs = new ArrayList<Job>();

        for (Job job : allJobs) {
            String requiredSkills = job.getSkillsRequired();
            if (requiredSkills != null && seekerSkills != null) {
                String[] seekerSkillsArray = seekerSkills.toLowerCase().split(",");
                for (String skill : seekerSkillsArray) {
                    if (requiredSkills.toLowerCase().contains(skill.trim())) {
                        suggestedJobs.add(job);
                        break; // Match found, go to next job
                    }
                }
            }
        }

        return suggestedJobs;
    }


}





















